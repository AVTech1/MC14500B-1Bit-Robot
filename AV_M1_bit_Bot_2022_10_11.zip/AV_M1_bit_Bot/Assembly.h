/* *************************************************************
 *  We maken een blok met hierin een aantal korte assembly
 *  programma onderdelen.
 *                                            AV_Retro@20211219
 *  
 * ************************************************************* 
*/ 

// *************************************************************
// ** opzoek tabel voor assembly instructies
// *************************************************************
int Zoek_op(char Scan_re[]){
  // Serial.print("Zoek op >>");
  // Serial.print(Scan_re);
  // Serial.println("<<");
  if (strcmp(Scan_re, "nopo") ==0 ) {
    return 0;  
  }  
  else if (strcmp(Scan_re, "NOPO") ==0 ){
    return 0;
  }
  else if (strcmp(Scan_re, "ld") ==0 ){
    return 1;
  }
  else if (strcmp(Scan_re, "LD") ==0 ){
    return 1;
  }
  else if (strcmp(Scan_re, "ldc") ==0 ){
    return 2;
  }
  else if (strcmp(Scan_re, "LDC") ==0 ){
    return 2;
  }
  else if (strcmp(Scan_re, "and") ==0 ){
    return 3;
  }
  else if (strcmp(Scan_re, "AND") ==0 ){
    return 3;
  }
  else if (strcmp(Scan_re, "andc") ==0 ){
    return 4;
  }
  else if (strcmp(Scan_re, "ANDC") ==0 ){
    return 4;
  }
  else if (strcmp(Scan_re, "or") ==0 ){
    return 5;
  }
  else if (strcmp(Scan_re, "OR") ==0 ){
    return 5;
  }
  else if (strcmp(Scan_re, "orc") ==0 ){
    return 6;
  }
  else if (strcmp(Scan_re, "ORC") ==0 ){
    return 6;
  }
  else if (strcmp(Scan_re, "xnor") ==0 ){
    return 7;
  }
  else if (strcmp(Scan_re, "XNOR") ==0 ){
    return 7;
  }
  else if (strcmp(Scan_re, "sto") ==0 ){
    return 8;
  }
  else if (strcmp(Scan_re, "STO") ==0 ){
    return 8;
  }
  else if (strcmp(Scan_re, "stoc") ==0 ){
    return 9;
  }
  else if (strcmp(Scan_re, "STOC") == 0) {
    return 9;
  }
  else if (strcmp(Scan_re, "ien") ==0 ){
    return 10;
  }
  else if (strcmp(Scan_re, "IEN") ==0 ){
    return 10;
  }
  else if (strcmp(Scan_re, "oen") ==0 ){
    return 11;
  }
  else if (strcmp(Scan_re, "OEN") ==0 ){
    return 11;
  }
  else if (strcmp(Scan_re, "jmp") ==0 ){
    return 12;
  }
  else if (strcmp(Scan_re, "JMP") ==0 ){
    return 12;
  }
  else if (strcmp(Scan_re, "rtn") ==0 ){
    return 13;
  }
  else if (strcmp(Scan_re, "RTN") ==0 ){
    return 13;
  }
  else if (strcmp(Scan_re, "skz") ==0 ){
    return 14;
  }
  else if (strcmp(Scan_re, "SKZ") ==0 ){
    return 14;
  }
  else if (strcmp(Scan_re, "nopf") ==0 ){
    return 15;
  }
  else if (strcmp(Scan_re, "NOPF") ==0 ){
    return 15;
  }
  else{
    return 100;       // betekend geen geldige instructie gevonden
  }
}
// *************************************************************

// *************************************************************
// ** Is het byte een Letter ??? *******************************
// *************************************************************
int IsLetter(int Reken){
  if ((Reken >= 97) && (Reken <= 122) || (Reken >= 65) && (Reken <= 90) ){
    return 1;  
  }
  else {
    return 0;
  }
}
// *************************************************************

// *************************************************************
// ** Is het byte een Cijfer ??? *******************************
// *************************************************************
int IsCijfer(int Reken){
  if ((Reken >= 48) && (Reken <= 57)){
    return 1;
  } 
  else {
    return 0;
  }
}
// *************************************************************

// *************************************************************
// ** Is het byte een Spatie of TAB ??? ************************
// *************************************************************
int IsSpatie(int Reken){
  if ((Reken == 32) || (Reken == 9) ) {
    return 1;
  }
  else {
    return 0;
  }
}
// *************************************************************

// *************************************************************
// ** Is het byte een TAB ??? **********************************
// *************************************************************
int IsTab(int Reken){
  if (Reken == 9)  {
    return 1;
  }
  else {
    return 0;
  }
}
// *************************************************************

// *************************************************************
// ** Is het byte een PuntKomma ??? ****************************
// *************************************************************
int IsPuntKomma(int Reken){
  if (Reken == 59) {
    return 1;
  }
  else {
    return 0;
  }
}
// *************************************************************

// *************************************************************
// ** Is het byte Einde vd Regel ??? ***************************
// *************************************************************
int IsEindeRegel(int Reken){
  if ((Reken == 13) || (Reken == 10)) {
    return 1;
  }
  else {
    return 0;
  }
}
// *************************************************************

// Een vervolg
